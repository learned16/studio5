# التوسع بعيد المدى — Long Term Expansion

**الحالة:** مرجع معماري خلفي — **ليس** نطاق تنفيذ حالي. راجع `YEAR_ONE_SCOPE.md` لما يُبنى الآن فعليًا.
**المصدر:** *Studio5 — Baseline Context for Work v1.0*.

هذا الملف يشرح لماذا لا تُبنى المعمارية الحالية بطريقة تمنع التوسع، من دون تنفيذ أي شيء منه الآن.

---

## 1. الهوية بعيدة المدى

Studio5 نظام يتذكر كل ما تعلمه المستخدم وطبّقه وأخطأ به، ويربط الدراسة بالمشاريع والبرامج والموقع والخبرة، ثم
يسترجع الشيء المناسب في الوقت المناسب:

```
Capture → Link → Remember → Warn → Apply → Learn
```

الهدف الأعلى (بعد السنوات الخمس): مساعد شخصي يفهم دراسة المستخدم، مشاريعه، أخطاءه، خبرته، ملفاته، البرامج
التي يستخدمها، وسياقه عبر الهاتف والتابلت والكمبيوتر.

## 2. المحركات الداخلية الثمانية (رؤية كاملة، ليست نطاق V1)

| # | المحرك | المسؤولية |
|---|---|---|
| 1 | Core Learning | المواد، المحاضرات، الفهم، المراجعة، الامتحانات، الدرجات والمسائل |
| 2 | Design Studio Engine | الـBrief، الموقع، البرنامج، العلاقات، البدائل، القرارات، النقد والمراجعات |
| 3 | Drawing & Digital Representation | الرسم اليدوي والهندسي، Ink PDF، الإظهار، الملفات الرقمية |
| 4 | Practice Lab | تعلم البناء والتنفيذ — Virtual Building، Interior، Physical Work |
| 5 | Building & Engineering Systems | المفاهيم الإنشائية والأنظمة، المسائل، الافتراضات والتحقق المعقول |
| 6 | Site, Planning & Infrastructure | تحليل الموقع، الزيارات، المساحة والطرق (لاحقًا) |
| 7 | Performance, Quantity & Project Delivery | المناخ، الطاقة، المواد، الكميات، المواصفات، الاقتصاد |
| 8 | Research, Skills & Portfolio & Experience | المصادر، البحث، الذاكرة، المهارات، الأدلة، الـPortfolio |

في السنة الأولى، **محرك واحد فقط فعّال بقوة: Drawing & Digital Representation (عبر Drawing Coach Lite)**،
مع حد أدنى من Core Learning إذا بقي وقت. بقية المحركات محجوزة معماريًا فقط.

## 3. نموذج التوسع للسنوات اللاحقة

السنة الثانية **لا تعني** إعادة بناء Studio5. التوسع الصحيح:

- إضافة `Year Two Subject Profiles` وبيانات المنهج فقط.
- إضافة `Capability Packs` للمواد الجديدة فقط.
- إضافة كيانات أو علاقات جديدة عبر `Versioned Migrations`.
- تفعيل الميزات بـ`Feature Flags` حسب السنة والمادة والجهاز.
- الحفاظ الكامل على ملفات وملاحظات ومهام وخبرة السنة الأولى.
- ترقية Core تدريجيًا مع `Backward Compatibility` وخطة `Rollback`.

**اختبار مستقبلي إلزامي:** قبل قبول أي معمارية، يجب إثبات بسيناريو اختبار فعلي أن إضافة Year 2 لا تمسح
Year 1 ولا تُنشئ قاعدة بيانات جديدة.

### مثال إضافة السنة الثانية (تسلسل)

1. إضافة تعريف السنة الثانية والمواد الجديدة كبيانات.
2. تفعيل Capability Packs المطلوبة.
3. تشغيل Migration جديدة إذا احتجنا كيانات إضافية.
4. تبقى مواد وتمارين وبيانات السنة الأولى قابلة للفتح والتصدير.
5. **لا نسخ للتطبيق، ولا مشروع جديد.**

## 4. خارطة الإصدارات (رؤية كاملة — للسياق فقط)

| الإصدار | النطاق (رؤية بعيدة المدى، غير مفعّلة الآن) |
|---|---|
| Foundation | Core Modular، Data Model/IDs/Relations، Ink foundation، Inbox، Change Ledger، Offline/Autosave/Recovery |
| V1-A | Year/Semester/Subjects/Schedule، Today، Lecture Capture، PDF/Notebook، Understanding Rescue، Search |
| V1-B | Assessments، Grades، Rubrics، Exam Mastery، Workload، Submission Gate، Professor Intelligence |
| **V1-C (⟵ ما يقارب نطاق السنة الأولى الفعلي)** | Project Lite، Brief، Alternatives، Feedback، Drawing Coach Lite، Skills/Evidence، Portfolio Capture |
| V1.5 | Rescue متقدم، Design Studio Coach، Bubble/Zoning، Interior 2D أساسي، Structural Intuition |
| V2 | Personal AI، Adaptive Learning، Virtual Building، Research، AI Orchestration |
| V3 | Desktop Companion وRemote Work على مراحل |
| V4 | BIM/Revit/CAD/3D/Performance/Structural/Site/AR/BOQ عميق |

> ملاحظة مهمة: خارطة الإصدارات هذه من *Baseline Context v1.0* أوسع من قرار *Year One Authority Handoff*.
> النطاق الفعلي المعتمد للتنفيذ الحالي موجود حصرًا في `YEAR_ONE_SCOPE.md`، وهو يقارب جزءًا من V1-A + V1-C فقط
> (Today مبسّط + Study مبسّط + Drawing Coach Lite)، **بدون** Assessments/Grades/Rubrics الكاملة و**بدون**
> Project الكامل. أي فجوة بين هذا الجدول ونطاق السنة الأولى مقصودة ويجب عدم "تعويضها" بصمت.

## 5. نموذج البيانات الموسّع (رؤية كاملة)

### أنواع علاقات (Typed Relations) — أمثلة
```
Lecture CONTAINS Note
Feedback APPLIES_TO ProjectVersion
Task IMPLEMENTS Feedback
Evidence PROVES Skill
Render GENERATED_FROM ProjectVersion
Question SEEKS_CLARIFICATION_FROM ProfessorReview
Memory DERIVED_FROM Experience
Deliverable SATISFIES Requirement
```

### مجالات كيانات رئيسية (رؤية كاملة)
| المجال | الكيانات الرئيسية |
|---|---|
| أكاديمي | AcademicYear, Semester, Subject, Lecture, Material, Notebook, Task, Assessment, Grade, Topic, ReviewItem, Problem, Error |
| مشروع | Project, ProjectMode, Brief, Requirement, Assumption, SiteRecord, Space, Alternative, Decision, Feedback, ProjectVersion, Deliverable |
| خبرة | ExperienceRecord, Memory, Lesson, Skill, Evidence, ProfessorPreference, RecurringError, PortfolioItem |
| ملفات | Workspace, FileRecord, Artifact, Preview, HashRecord, ExternalLink, RecoverySnapshot |
| أتمتة (لاحقًا) | Device, CommandJob, Preset, Approval, Adapter, ArtifactDelivery, PermissionScope |
| AI (لاحقًا) | AITask, ModelProfile, RouteDecision, CouncilSession, AIResult, CostRecord, SourceCitation |

راجع `docs/SEED_MODEL_DATA.md` للمجموعة الفعلية المطلوبة في السنة الأولى فقط (زيرمجموعة صغيرة من هذا الجدول).

## 6. AI Orchestration ومجلس الذكاء الاصطناعي (رؤية كاملة — مؤجلة)

Studio5 لا يرتبط بنموذج واحد على المدى الطويل. كل AI Task يُعرَّف منطقيًا، ثم Router يختار Local أو Cloud أو
Specialized أو Council حسب المخاطر والكلفة والخصوصية. **لا شيء من هذا مفعّل في السنة الأولى.**

سياسة الميزانية المستقبلية (للسياق فقط): تشغيل يومي منخفض جدًا (Local/Cache)، مع سقف استثنائي مؤقت لا يتجاوز
عادة ما يقارب 100 دولار لفترات مثل مشروع التخرج، بعد موافقة صريحة — **ليست** ميزانية شهرية ثابتة ولا هدف
إنفاق.

## 7. الأجهزة والتوسع المستقبلي (Desktop Companion)

برنامج Windows منفصل تمامًا عن Core، مسؤول لاحقًا عن الأجهزة والملفات الثقيلة وفتح البرامج والرندر والتصدير.
أي فشل فيه **لا يؤثر** في Core. كل تكامل مع برنامج خارجي (Revit/AutoCAD) يكون عبر Adapter معزول بعقد ثابت
(`IsInstalled`, `OpenProgram`, `OpenFile`, `RunPreset`, `CollectArtifacts`, إلخ) — **لا شيء من هذا يُبنى في
السنة الأولى.**
