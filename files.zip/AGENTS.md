# AGENTS.md — قواعد ملزمة لأي وكيل يكتب كودًا

هذا الملف موجّه لأي Agent تنفيذي (Codex Builder أو ما يعادله). اقرأ `AR_HERE_START.md` و`docs/YEAR_ONE_SCOPE.md`
و`docs/MASTER_EXECUTION_SPEC.md` **قبل** هذا الملف إن لم تكن قد قرأتها.

---

## 1. القاعدة الأولى: لا تقييم ذاتي

> الوكيل الذي كتب الكود لا يحق له اعتبار عمله ناجحًا وحده.

النجاح يُثبت بأدوات مستقلة، اختبارات، Diff، ومراجعة — لا بتصريح "تم بنجاح" من نفس الوكيل.

## 2. تدفق العمل (Workflow)

```
Requirement → Small Task → Builder → Build/Lint/Type Check → Tests → Guards →
Independent Reviewer → Acceptance → Evidence Report → Merge Approval
```

- كل دفعة (Batch) صغيرة، محدودة الملفات، ولها معايير قبول واختبارات ورجوع (Rollback) واضح.
- **ممنوع** استلام "أكمل التطبيق" أو أي طلب عام غير مقسَّم.
- لا تُنفَّذ دفعة بدون معرّف Requirement من `docs/TRACEABILITY.md`.

## 3. Skills Guard — إلزامي كـSecond-Pass

بعد إنتاج أي دفعة، شغّل:

```
Use $clean-code-guard on the diff you just produced
Use $test-guard on the tests you just wrote
Use $docs-guard on the documentation changes before shipping
```

المستودع المعتمد: `amElnagdy/guard-skills`. تحقق من آخر إصدار وأوامر التثبيت من المصدر الرسمي وقت التنفيذ
(الأدوات تتغير):

```
npx skills add amElnagdy/guard-skills --skill clean-code-guard --agent codex --project
npx skills add amElnagdy/guard-skills --skill test-guard --agent codex --project
npx skills add amElnagdy/guard-skills --skill docs-guard --agent codex --project
npx skills update --project
```

> **Skills Guard ليس بديلًا عن Tests وCI ومراجعة مستقلة** — هو فحص إضافي بعد أن ينتج الوكيل العمل.

### ما تكشفه كل Guard
| Guard | المشاكل المستهدفة |
|---|---|
| clean-code-guard | Over-abstraction، duplication، broad catch، fake success، hallucinated APIs، bad names، Contract changes |
| test-guard | Mock abuse، duplicate tests، implementation-detail assertions، tests that catch nothing، حذف regressions |
| docs-guard | Docs drift، رموز أو أمثلة غير موجودة، claims غير قابلة للتحقق |

## 4. الأدوات الإلزامية الأخرى

Formatter، Linter، Static Type Check، Unit Tests، Integration Tests، E2E Tests (عند الحاجة)، Migration &
Rollback Tests، Backup/Restore Tests، Security/Dependency/Secret Scans. **CI يمنع الدمج عند الفشل.**

## 5. ممنوعات صارمة على الوكيل

- تغيير Architecture أو Contract دون تسجيل في `docs/LEDGER_CHANGE.md` وموافقة.
- حذف Test أو تعطيل Type/Lint Check لجعل المهمة "تنجح".
- إخفاء الخطأ بـ`catch` واسع.
- استخدام API أو Package مخترع (Hallucinated).
- تعديل Migration مستخدمة سابقًا (أضف migration جديدة بدلًا من ذلك).
- استبدال ملف أصلي بصمت.
- ترك `TODO` مكان الوظيفة مع إعلان الاكتمال.
- إضافة Dependency جديدة بلا مبرر مكتوب.
- Refactor جانبي كبير لمهمة صغيرة.
- إعلان النجاح بلا أوامر ونتائج وأدلة فعلية.
- **البدء بكتابة كود التطبيق الكامل أو اختيار Tech Stack نهائي قبل نجاح Technical Gate 0 وموافقة المستخدم
  الصريحة على Design Freeze.** الاستثناء الوحيد: Prototypes معزولة غير إنتاجية (`prompts/gate_0_technical.md`).

## 6. Definition of Done

راجع `docs/ACCEPTANCE_CRITERIA.md` §5 للقائمة الكاملة. ملخص:
Tests/Build/Guards ناجحة، Docs محدَّثة، لا فقد بيانات، اختبار جهاز حقيقي عند الحاجة، تقرير
`PASS`/`FAIL`/`NEEDS DECISION` مع الأدلة.

## 7. تقرير كل دفعة (نموذج مطلوب)

| الحقل | المحتوى |
|---|---|
| Status | PASS / FAIL / NEEDS DECISION |
| What changed | شرح طبيعي مختصر |
| Evidence | Build، Tests، Guards، Screenshots، Diff Summary |
| Remaining risks | ما لم يُختبر أو ما يزال غير مؤكد |
| User decisions | خيارات بلغة واضحة مع توصية |

راجع `.github/PULL_REQUEST_TEMPLATE.md` — كل Pull Request يجب أن يملأ هذا الجدول.

## 8. الوكيل لا يدمج (Merge) من نفسه

بعد التقرير، ينتظر الوكيل مراجعة مستقلة (`CLAUDE.md`) وموافقة المستخدم قبل الدمج (Merge) في الفرع الرئيسي.
