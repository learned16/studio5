## معلومات الدفعة

- **Requirement ID(s):** (من `docs/TRACEABILITY.md`)
- **Phase / Milestone:** (من `docs/ROADMAP_12_WEEKS.md`)

## Status
- [ ] PASS
- [ ] FAIL
- [ ] NEEDS DECISION

## What changed
<!-- شرح طبيعي، لا وصف تسويقي -->

## Evidence
- **Build:**
- **Lint / Type Check:**
- **Unit / Integration Tests:**
- **Guards:**
  - [ ] clean-code-guard — ناجح
  - [ ] test-guard — ناجح
  - [ ] docs-guard — ناجح
- **اختبار جهاز حقيقي (إن انطبق على قلم/PDF/Offline):**
- **Diff Summary:**

## Checklist (Definition of Done — راجع docs/ACCEPTANCE_CRITERIA.md §5)
- [ ] مرتبط بمعرّف في TRACEABILITY.md
- [ ] لا ميزة خارج نطاق YEAR_ONE_SCOPE.md تسللت لهذه الدفعة
- [ ] لا فقد بيانات أو تغيير Contract غير مصرَّح به
- [ ] لا Migration معدَّلة بأثر رجعي
- [ ] لا catch واسع يخفي الخطأ
- [ ] لا API/Package مخترع
- [ ] Docs محدَّثة (schema/API + changelog)
- [ ] تغييرات معمارية/Contract مسجَّلة في `docs/LEDGER_CHANGE.md`

## Remaining risks
<!-- ما لم يُختبر أو ما يزال غير مؤكد -->

## User decisions needed
<!-- خيارات بلغة واضحة مع توصية، إن وُجدت -->

## Rollback plan
<!-- كيف نتراجع عن هذه الدفعة إذا لزم الأمر -->
