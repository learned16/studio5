# القرارات المعمارية — Architecture Decision Records (ADR)

**قاعدة إلزامية:** ممنوع اختيار أي تقنية لأنها شائعة أو لأن الوكيل يفضلها. كل قرار تقني كبير يخرج بصيغة ADR:
**المشكلة → الخيارات → المعايير → المقارنة → التوصية → المخاطر → خطة Prototype → قرار المستخدم.**

هذا الملف يفصل بين ما تم حسمه فعلًا (Approved) وما لا يزال مفتوحًا (Open / Needs Prototype). **لا تُعتبر أي
تقنية مذكورة هنا كخيار "مرشّح" قرارًا نهائيًا** إلا إذا كانت الحالة `Approved` صراحة.

---

## 1. قرارات معمارية عليا معتمدة (Approved)

هذه مبادئ حُسمت في الوثائق المصدر ولا تُعاد مناقشتها إلا عند تعارض تقني موثّق يمنع التنفيذ:

| القرار | الحالة |
|---|---|
| Modular Monolith بدل Microservices في V1 | Approved |
| Studio5 Core دائم واحد، لا تطبيق منفصل لكل سنة | Approved |
| Offline-first لجميع الوظائف الأساسية | Approved |
| Feature Parity بين الأجهزة (الاختلاف في Layout فقط) | Approved |
| No Silent Change — كل تعديل نطاق يُسجَّل ويُعتمد | Approved |
| Drawing Coach Lite بتقييم رياضي محلي بدون AI في V1 | Approved |
| Work يخطط، Codex ينفذ دفعات صغيرة، مراجعة مستقلة إلزامية | Approved |
| Skills Guard (`clean-code-guard`, `test-guard`, `docs-guard`) كـ Second-pass إلزامي، **ليس** بديلًا عن Tests/CI/مراجعة | Approved |
| Prototype على MatePad الحقيقي **قبل** تثبيت أي Tech Stack | Approved |

---

## 2. القرارات المفتوحة المسموح لـ Work حسمها (Open — Needs Comparison + Prototype)

هذه الأسئلة التقنية الحقيقية فقط. **لا يُعاد فتح أي قرار محسوم أعلاه لمجرد وجود بديل تقني.**

### ADR-01 — Cross-Platform Strategy
- **المشكلة:** أفضل Stack يدعم Android/HarmonyOS وWindows، مع Ink/PDF/Offline جيدة، بعد Prototype وقياس.
- **الخيار المرشّح للاختبار الأول:** Flutter (مذكور في *Year One Built* كـ"قرار مشروط قبل التجربة").
- **الحالة:** `Needs Decision` — يُحسم فقط بعد Technical Gate 0.
- **معيار الحسم:** أداء القلم (latency)، دعم الضغط/الميل، الاستقرار، سهولة بناء Windows + Web احتياطي.

### ADR-02 — Local Database & Sync Protocol
- **المشكلة:** شكل قاعدة البيانات المحلية وبروتوكول المزامنة ومزوّد التخزين الأولي.
- **الخيار المرشّح للاختبار:** Drift/SQLite أو بديل محلي مماثل.
- **الحالة:** `Open`.

### ADR-03 — Ink Storage (Strokes)
- **المشكلة:** طريقة تخزين strokes الحبر ومعاينتها وضغطها.
- **الحالة:** `Open` — يُختبر ضمن Shared Ink Engine Prototype.

### ADR-04 — PDF Rendering/Annotation Engine
- **المشكلة:** أنسب محرك PDF، ترخيصه، وأداؤه مع ملفات كبيرة على MatePad.
- **الحالة:** `Open`.

### ADR-05 — Native Wrapper vs Cross-Platform Framework vs Web/PWA
- **المشكلة:** حدود استخدام Cross-Platform Framework مقابل Native Wrapper مقابل Web/PWA.
- **الحالة:** `Open` — مرتبط بـADR-01.

### ADR-06 — Local Indexing & Search (V1)
- **المشكلة:** آلية Indexing المحلي والبحث في السنة الأولى.
- **الحالة:** `Open`.

### ADR-07 — Backup Manifest & Full Export Format
- **المشكلة:** تصميم صيغة `Full Export` و`Backup Manifest` القابلة للفهم والاستعادة الفعلية.
- **الحالة:** `Open`.

### ADR-08 — Drawing Coach Lite Scoring Algorithms
- **المشكلة:** أبسط خوارزميات (استقامة، توازي، تعامد، تقارب نقاط التلاشي، إغلاق الشكل) تعطي فائدة صادقة دون
  ادعاء مبالغ فيه.
- **الحالة:** `Open` — تُختبر ضمن Prototype Drawing Coach.

### ADR-09 — Desktop Companion / IPC Technology *(مؤجل، غير نشط الآن)*
- **الحالة:** `Deferred` — خارج نطاق V1 بالكامل. يُفتح فقط عند الوصول لمرحلة V3.

### ADR-10 — Local AI Runtime وحدود الأجهزة *(مؤجل)*
- **الحالة:** `Deferred` — لا AI في V1.

### ADR-11 — Secret Management / Encryption / Auth
- **المشكلة:** آلية تخزين آمنة للمفاتيح (إن وُجدت لاحقًا) وقفل الحساب المحلي (Biometric/PIN).
- **الحالة:** `Open` — أساسي حتى في V1 (قفل محلي)، تفاصيل التشفير المتقدم `Deferred` مع ميزات Cloud.

### ADR-12 — CI/CD واستضافة البيئات
- **المشكلة:** إعداد CI يمنع الدمج عند الفشل، بيئات الاختبار.
- **الحالة:** `Open` — يُحسم في مرحلة Foundation (Phase 0 من `ROADMAP_12_WEEKS.md`).

### ADR-13 — Telemetry وCrash Reports مع الخصوصية
- **المشكلة:** ما الذي يُجمع، وأين يُخزَّن، وكيف يُعرض للمستخدم بشفافية.
- **الحالة:** `Open`.

---

## 3. كل سؤال آخر

أي سؤال تقني لم يُذكر أعلاه ويبدو مغريًا لإعادة فتحه (مثلًا اختيار نموذج AI، أو بنية Microservices، أو Sync
سحابي كامل) **يُعتبر محسومًا مسبقًا كـDeferred/Out of Scope** حسب `YEAR_ONE_SCOPE.md` §3، ولا يُعاد طرحه إلا
عند ظهور تعارض تقني موثّق يمنع تنفيذ Must-Have الحالي.

---

## 4. قالب ADR جديد

عند حسم أي قرار من القسم 2، أضف سجلًا هنا بهذا الشكل، وسجّل التغيير أيضًا في `LEDGER_CHANGE.md`:

```markdown
### ADR-XX — [العنوان]
- **المشكلة:**
- **الخيارات المقارنة:**
- **المعايير:**
- **التوصية:**
- **المخاطر:**
- **نتيجة Prototype (إن وجدت):**
- **قرار المستخدم:** [Approved / Rejected] — بتاريخ [YYYY-MM-DD]
```
