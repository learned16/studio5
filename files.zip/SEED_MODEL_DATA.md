# بذرة نموذج البيانات — Seed Model & Typed Relations

هذا الملف يحدد **الكيانات والعلاقات الفعلية المطلوبة في السنة الأولى فقط**. المجموعة الكاملة الموسّعة (كل
المجالات المستقبلية) موجودة في `LONG_TERM_EXPANSION.md` §5 كمرجع خلفي — لا تُنفَّذ الآن.

---

## 1. مبادئ إلزامية للنموذج

- كل كيان يملك **Stable ID** لا يتغيّر مع الاسم أو النقل أو تغيير المادة.
- كل سجل يملك: `CreatedAt`, `UpdatedAt`, `Source`, `Confidence` (حيث ينطبق), `Status`, `Version`, `Ownership`.
- السجل نفسه يظهر في عدة واجهات من دون نسخ منفصلة (`Unified Records`).
- العلاقات **Typed** صراحة، وليست مجرد Tags حرة.
- أي تغيير في Schema يحتاج Migration مُختبرة (تقدّم وتراجع).

---

## 2. الكيانات المطلوبة في السنة الأولى

### المجال الأكاديمي
`AcademicYear`, `Semester`, `Subject`, `Lecture`, `Material`, `Notebook`, `Task`, `Topic`

### مجال الملفات
`Workspace`, `FileRecord`, `Artifact`, `Preview`, `HashRecord`, `RecoverySnapshot`

### مجال الحبر والرسم (Drawing Coach Lite)
`DrawingSession`, `Exercise`, `Attempt`, `Stroke`, `Overlay`, `SkillTrack` (Line Control / Shapes /
Perspective فقط), `ProgressSnapshot`

### مجال الأتمتة الداخلية (سجلات فقط، لا تنفيذ فعلي)
`ChangeLedgerEntry`

> **ملاحظة:** كيانات `Project`, `Brief`, `Requirement`, `Alternative`, `Decision`, `ProfessorReview`,
> `ExperienceRecord`, `Skill` (الهرمي الكامل), `PortfolioItem`, `Assessment`, `Grade`, `Rubric` — كلها
> موجودة في الرؤية الكاملة (`LONG_TERM_EXPANSION.md`) لكنها **خارج نطاق تنفيذ السنة الأولى** حسب
> `YEAR_ONE_SCOPE.md` §3 (Out of Scope). لا تُنشأ جداول أو نماذج لها الآن حتى لو بدت "سهلة الإضافة".

---

## 3. Typed Relations المطلوبة في السنة الأولى

```
Subject CONTAINS Lecture
Lecture CONTAINS Note
Lecture HAS_MATERIAL Material
Notebook BELONGS_TO Subject
Task DERIVED_FROM Lecture           (عبر Closeout)
FileRecord BELONGS_TO Workspace
Attempt BELONGS_TO Exercise
Attempt BELONGS_TO DrawingSession
Overlay GENERATED_FROM Attempt
ProgressSnapshot DERIVED_FROM Attempt
```

توسّع لاحقًا (رؤية كاملة، غير مفعّلة الآن) — أمثلة:
```
Feedback APPLIES_TO ProjectVersion
Task IMPLEMENTS Feedback
Evidence PROVES Skill
Question SEEKS_CLARIFICATION_FROM ProfessorReview
Memory DERIVED_FROM Experience
Deliverable SATISFIES Requirement
```

---

## 4. Subject Profile / Capability Pack / Year Release Profile (بنية التوسع)

هذه البنية **تُبنى الآن** (كجزء من Core) حتى لو لم تُستخدم إلا لسنة واحدة، لأنها شرط عدم إعادة البناء لاحقًا:

```yaml
# مثال Year Release Profile
academic_year_level: 1
subject_profiles:
  - id: subj_arch_drawing_y1
    name_official: "..."   # من الكتالوج الرسمي — لا تُخترع أسماء مواد
capability_packs:
  - drawing_foundations
  - engineering_drawing
feature_flags:
  drawing_coach_lite: true
  advanced_ai_coach: false
  desktop_companion: false
schema_min_version: 1
```

- `Subject Profile`: تعريف بيانات المادة — الاسم الرسمي، الرمز، السنة والفصل، نوع المادة، المحركات
  المطلوبة، القوالب، Skill mappings.
- `Capability Pack`: حزمة قدرات عامة قابلة لإعادة الاستخدام (المادة لا تحتوي كودًا خاصًا بها).
- `Year Release Profile`: يحدد ما يُفعَّل في السنة الحالية فقط.

**مصدر أسماء المواد:** يُستخرج `Curriculum Map` حصرًا من ملف الكتالوج الرسمي المرفوع داخل المشروع (سنة/فصل/
مادة). **ممنوع اختراع أسماء مواد.**
