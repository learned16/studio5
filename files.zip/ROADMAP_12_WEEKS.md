# خطة التنفيذ — Roadmap (~12–13 أسبوعًا)

**السلطة:** المراحل الكبرى (Phase 0–6) من *Year One Authority Handoff v1.1* — هي البنية الملزمة. التفاصيل
الأسبوعية الدقيقة من *Year One: What Will Be Built* مدمجة داخل كل مرحلة كمرجع تفصيلي، وقابلة لتعديل Work بعد
تحليل واقعي — **لكن لا يحق لأي وكيل إدخال ميزات مؤجلة لتعويض وقت فائض، ولا حذف أساسيات الاعتمادية لتسريع
العرض.**

الترتيب حسب الاعتماديات: لا تُبنى واجهات كبيرة قبل ثبات القلم والحفظ والاستعادة.

---

## Phase 0 — أسبوع 1: التأسيس
**المخرجات:** Context Ingestion، Decision Ledger، Master Specification، اختيارات Prototype، إعداد Repo وCI
ومعايير الكود.
- تهيئة GitHub، Flutter (أو البديل المُختار)، CI.
- بداية تجربة القلم الأولية.
- **الناتج:** قرار المنصة الأولي (غير نهائي — ينتظر Gate 0).

## Phase 1 — أسبوعان: Technical Gate 0 (Prototype حقيقي)
**المخرجات:** Prototype حقيقي على MatePad — PDF + Ink + Export + Reopen + Autosave. **قرار التقنية النهائي
يأتي بعد القياس**، ليس قبله.
- تفصيل تدريجي: Stroke lifecycle، قلم وممحاة، Undo/Redo → Shared Ink Core.
- Pan/Zoom وخلفيات وطبقات وتحسين الأداء → جلسة رسم مستقرة.
- **بوابة قرار (Go/No-Go):** لا ننتقل لـPhase 2 قبل نجاح `ACCEPTANCE_CRITERIA.md` §1 بالكامل.

## Phase 2–3 — أسابيع 2–3: Core Data Model
**المخرجات:** Core data model، Subjects، Schedule، Today، Tasks، Files، Notebook basics، Local database.
- Stable IDs لكل مادة/تمرين/محاولة/مهارة.
- Versioned Migrations من اليوم الأول (حتى لو لم تُستخدم إلا لاحقًا).
- Feature Flags للقدرات التدريجية.

## Phase 3 — 3 أسابيع: نظام التدريب (Drawing Coach Framework)
**المخرجات:** نظام التمارين والجلسات والمحاولات والـOverlays (Framework التدريب).
- Line Control: استقامة، توازي، تعامد، مسافات.
- Shapes: مستطيلات، دوائر، أقواس، تركيب أشكال.
- Perspective Basics: نقطة تلاشي ومنظور نقطة واحدة.
- (منظور نقطتين: يُنفَّذ فقط إذا بقي وقت بعد ثبات الأساس — راجع `YEAR_ONE_SCOPE.md`).

## Phase 3 (موازٍ) — Lecture & Capture Flow
**المخرجات:** Lecture flow، Capture، Closeout، Unified Inbox، Search، Favorites/Recent، Offline queue.

## Phase 4 — أسبوعان: سلامة البيانات
**المخرجات:** Sync/Backup/Export/Restore، Conflicts، Privacy، Lock، Recovery، Observability.
- نموذج المهارات ونقاط الضعف والتمرين التالي (Progress).
- Study Shell: السنة والفصل والمواد وToday بسيط.

## Phase 5 — أسبوعان: التكامل والتحليلات
**المخرجات:** Drawing Coach Lite analytics، ربط المحاولات بالتقدم.
- PDF مرجعي وNotebook بسيط + Backup UX.
- تكامل أساسي بين الوحدات.

## Phase 6 — أسبوع: Hardening
**المخرجات:** اختبارات جهاز حقيقي، إصلاحات، seed data، دليل استخدام، **Release Candidate**.

---

## إذا تأخرنا — ماذا نحذف أولًا؟ (بالترتيب)

1. Cloud AI.
2. Cloud Sync.
3. التحليلات المتقدمة.
4. منظور نقطتين المتقدم.
5. PDF Annotation الكامل.
6. Today المتقدم والزخرفة غير الضرورية.

## ما لا نحذفه مهما ضاق الوقت

- سلاسة الرسم.
- الحفظ التلقائي (Autosave).
- الاستعادة بعد الانهيار.
- Offline.
- التمارين الأساسية.
- التقييم والتقدم.
- Backup وExport.
- معمارية التوسع للسنوات القادمة (Stable IDs, Versioned Schemas, Subject Profiles).

---

## بوابات القرار (Go / No-Go)

بعد كل Milestone تُوجد `Demo` على الجهاز الحقيقي وقرار **Go/No-Go** صريح من المستخدم قبل الانتقال للمرحلة
التالية. لا يُعلَن Milestone مكتملًا إن كانت الاستعادة أو التصدير أو التعارضات غير مجرَّبة فعليًا.
