# الأمر الجاهز — Technical Gate 0

**طريقة الاستخدام:** ارفع هذا المستودع كاملًا إلى Codex (أو أي وكيل تنفيذي)، ثم أرسل النص التالي **كما هو**.
لا تضف له طلب "أكمل التطبيق" أو أي توسيع.

---

## النص الجاهز للإرسال

```
اقرأ AR_HERE_START.md وكل وثائق docs/ ذات السلطة قبل أي تنفيذ. لا تبنِ التطبيق الكامل.

نفّذ Technical Gate 0 فقط:

1. Flutter scaffold (أو البديل المذكور في docs/ARCHITECTURE_DECISIONS.md ADR-01 إن وُجد قرار مختلف) يستهدف
   Android/HarmonyOS tablet + Windows + Web.
2. Canvas للقلم مع اكتشاف الضغط والميل إن وفّرهما الجهاز، ورفض راحة اليد (Palm Rejection) الأساسي.
3. Stroke persistence: حفظ آلاف نقاط الضربة محليًا واستعادتها بعد إعادة الفتح.
4. Autosave متكرر أثناء الرسم.
5. Force close recovery: إغلاق قسري ثم استعادة كاملة لآخر جلسة.
6. Offline كامل — لا اعتماد على إنترنت لأي من الوظائف أعلاه.
7. بناء Android/Windows/Web (Web كنسخة احتياطية فقط، ليست الهدف الأساسي).
8. تقرير أدلة صادق: أرقام فعلية (عدد strokes، زمن استجابة تقريبي، نتائج اختبار Force Close)، لا وصف عام.

توقف عند DECISION NEEDED إذا لم تتوفر نتيجة اختبار MatePad الحقيقي، أو إذا واجهت قرارًا معماريًا غير محسوم في
docs/ARCHITECTURE_DECISIONS.md.

ممنوع صراحة:
- بناء أي شاشة أو ميزة من ميزات المستخدم النهائية (Today, Study, Practice الكاملة, إلخ).
- إضافة قاعدة بيانات دائمة أو Sync قبل قرار Gate 0.
- اختيار Tech Stack نهائي بدون توثيق نتائج القياس على الجهاز الحقيقي.
- أي Dependency غير ضرورية لهذا الاختبار تحديدًا.

بعد التنفيذ:
1. شغّل Build/Lint/Type Check/Tests.
2. قدّم تقرير PASS/FAIL/NEEDS DECISION حسب docs/ACCEPTANCE_CRITERIA.md §1، مع الأدلة والمخاطر المتبقية.
3. لا تدمج (Merge) التغيير من نفسك.
```

---

## بعد نجاح Gate 0

1. المستخدم يختبر النموذج فعليًا على HUAWEI MatePad 11.5 PaperMatte.
2. تُملأ نتائج القياس في `docs/ARCHITECTURE_DECISIONS.md` (ADR-01 وما يتبعها من قرارات مرتبطة).
3. تُسجَّل القرارات المعتمدة في `docs/LEDGER_CHANGE.md`.
4. يبدأ Phase 2 من `docs/ROADMAP_12_WEEKS.md` (Core Data Model) — فقط بعد موافقة المستخدم الصريحة.

**لا يُنفَّذ أي "Handoff" كامل لبناء التطبيق قبل هذه الخطوات وموافقة صريحة على Design Freeze.**
