# Studio5 — Master Execution Specification

**الحالة:** `DRAFT — Needs Ingestion Review`
**السلطة:** هذا الملف يشرح **كيف** نبني، بينما `YEAR_ONE_SCOPE.md` يحسم **ماذا** نبني. عند تعارض حول النطاق،
`YEAR_ONE_SCOPE.md` يفوز.

> ⚠️ هذا مسودة تنفيذية أولية (v0.1) مبنية على *Starter Pack Overview* و*Year One Authority Handoff*. حسب
> إجراء الاعتماد الرسمي (`AGENTS.md` §Workflow)، لا تُعتبر هذه الوثيقة **معتمدة نهائيًا** إلا بعد:
> 1. Context Ingestion Report يثبت استيعاب كل الوثائق المصدر.
> 2. Decision Inventory (Adopted / Superseded / Deferred / Open).
> 3. Conflict Report للتعارضات الحقيقية فقط.
> 4. موافقة المستخدم الصريحة على **Design Freeze**.
> إلى أن يحدث ذلك، تُستخدم هذه المسودة كمرجع عمل لـ Technical Gate 0 والتخطيط فقط — **ليست** إذنًا ببدء كتابة
> كود التطبيق الكامل.

---

## 1. الهدف

بناء تطبيق شخصي يعمل يوميًا على التابلت والهاتف والكمبيوتر لمساعدة المستخدم على:

- تطوير الرسم اليدوي والهندسي والمنظور.
- إدارة الدراسة والمواد والمحاضرات والملفات.
- التقاط المطلوبات ونقاط عدم الفهم بسرعة.
- حفظ التقدم والأخطاء والخبرة من دون ضياع.
- التوسع عبر السنوات الخمس من نفس البيانات ونفس النظام.

## 2. قاعدة لا تفاوض

> السنة الأولى تبني `Studio5 Core` الدائم. لا توجد نسخة منفصلة لكل سنة.

إضافة سنة أكاديمية جديدة يجب أن تتم عبر سجلات وملفات تعريف وقدرات ومهاجرات إصدار، وليس عبر Fork أو تطبيق أو
قاعدة بيانات جديدة. راجع `docs/LONG_TERM_EXPANSION.md` للتفاصيل.

## 3. المستخدم والأجهزة

### التابلت — الجهاز الرئيسي
HUAWEI MatePad 11.5 PaperMatte مع قلم Huawei: Drawing Coach، PDF، Notebook، Markup، Split View، الدراسة
أثناء المحاضرة.

### Windows PC
إدارة وتنظيم أوسع، ملفات ثقيلة لاحقًا، عرض البيانات نفسها، Desktop Companion لاحقًا (منفصل عن Core تمامًا).

### الهاتف
Capture سريع، كاميرا، Today والمهام والتنبيهات. وظائف الجهاز الخاصة فقط تختلف، لا البيانات الأساسية.

> **Feature Parity:** اختلاف الأجهزة لا يعني تقسيم الميزات أو حجبها. جميع الأجهزة تصل إلى الحساب والبيانات
> والوظائف الأساسية نفسها؛ الاختلاف في Layout وأداة الإدخال والقدرة المحلية فقط.

## 4. المبادئ المعمارية

1. `Modular Monolith` في البداية.
2. `Local-first`: الوظائف الأساسية تعمل دون إنترنت.
3. `Stable IDs`: لا تعتمد الهوية على الاسم أو السنة أو مكان الملف.
4. `Unified Records`: السجل ذاته يظهر في عدة واجهات، لا نسخ متضاربة.
5. `Typed Relations`: العلاقات أنواع صريحة وليست Tags فقط.
6. `Immutable Originals`: ملفات PDF الأصلية لا تُعدّل بصمت.
7. `Shared Ink Engine`: الدفتر وDrawing Coach وPDF Annotation يستخدمون نفس أساس الحبر.
8. `Failure Isolation`: فشل AI أو Cloud أو Sync أو Desktop Companion لا يُسقط Core.
9. `Versioned Change`: المخططات والمهاجرات والعقود مُرقّمة.
10. `Feature Flags`: القدرات تُفعّل تدريجيًا.
11. `Data Ownership`: تصدير ونسخ احتياطي وحذف واضح.
12. `Plan future, implement current stage`.
13. `No Silent Change`: لا حذف أو دمج أو تأجيل أو تقليل نطاق بصمت — كل شيء في `LEDGER_CHANGE.md`.

## 5. بنية المجالات (Domains)

```text
Studio5 Core
├── Academic Domain
├── Project Domain            (Lite في V1 — يُوسَّع لاحقًا)
├── Knowledge Domain
├── Experience Domain
├── File & Artifact Domain
├── Shared Ink Domain
└── Automation Records Domain
```

لا توضع عمليات الرندر أو التحكم العام بالكمبيوتر داخل Core. هذه لاحقًا داخل Desktop Companion وAdapters
منفصلة تمامًا.

## 6. واجهات المنتج العليا

خمس واجهات عليا فقط، **بلا زيادة**:

| الواجهة | وظيفتها في V1 |
|---|---|
| Today | لوحة التنفيذ اليومية — محاضرات، مهام، آخر ملف، تنبيهات قابلة للتنفيذ |
| Study | المواد، المحاضرات، PDF والدفاتر، البحث |
| Projects | مبسّطة (Lite) — تُوسَّع في سنوات لاحقة |
| **Practice (Drawing Coach)** | **الواجهة الأساسية في V1** — تمارين، تقييم، تقدم |
| Library | ملفات ومراجع أساسية |

إضافة محرك داخلي جديد **لا تعني** إنشاء تبويب رئيسي جديد. المحركات تعمل خلف هذه الواجهات.

## 7. استراتيجية السنوات (ملخص)

راجع `docs/LONG_TERM_EXPANSION.md` للتفصيل الكامل. الفكرة المختصرة:

- **Core دائم** يحمل: الهوية، التخزين المحلي، Stable IDs، العلاقات، الملفات، Ink، النسخ الاحتياطي والاستعادة،
  البحث، Feature Flags، Capability Registry، Migration Engine.
- **Subject Profile**: تعريف بيانات المادة (الاسم، الرمز، السنة، الفصل، القدرات المطلوبة، القوالب).
- **Capability Pack**: حزمة قدرات قابلة للتفعيل (`drawing_foundations`, `engineering_drawing`, إلخ).
- **Year Release Profile**: ملف يحدد ما يُفعّل في السنة الحالية عبر Feature Flags.

## 8. النطاق التنفيذي الحالي

راجع `docs/YEAR_ONE_SCOPE.md` — المرجع الوحيد الملزم لما يُبنى الآن. الأولوية المختصرة:

1. Foundation Core (تخزين محلي، Stable IDs، Autosave/Recovery، Backup/Export).
2. Shared Ink Engine.
3. Drawing Coach Lite.
4. Data durability كاملة.
5. الحد الأدنى المفيد من Study/Today إذا بقي وقت آمن.

## 9. الذكاء الاصطناعي في V1

AI **ليس** أساسًا للحفظ أو الرسم أو إدارة المهام في السنة الأولى. تقييم Drawing Coach Lite حسابي محلي بالكامل
(هندسة رياضية بسيطة: استقامة، توازي، تعامد، تقارب نقاط التلاشي) — بدون AI وبدون إنترنت.

إذا استُخدم AI لاحقًا (شرح تقييم، اقتراح تمرين، تلخيص)، يجب أن يكون خلف Interface قابلة للاستبدال، مع: مصدر،
ثقة، تكلفة، حدود، موافقة عند البيانات الحساسة، وFallback محلي إجباري.

## 10. تعريف النجاح

راجع `docs/ACCEPTANCE_CRITERIA.md` للمعايير الكاملة القابلة للاختبار.
