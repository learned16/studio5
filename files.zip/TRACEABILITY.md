# مصفوفة التتبع — Requirement Traceability Matrix

كل متطلب في `MASTER_EXECUTION_SPEC.md` أو `YEAR_ONE_SCOPE.md` يجب أن يُمنح معرّفًا ثابتًا قبل أن يتحوّل إلى
دفعة Codex.

---

## 1. عائلات المعرّفات (ID Prefixes)

| النطاق | البادئة |
|---|---|
| Functional | `###-S5-FR` |
| Non-functional | `###-S5-NFR` |
| Security/Privacy | `###-S5-SEC` |
| Data/Sync/File | `###-S5-DATA` |
| PC/Automation *(مؤجل — لا يُستخدم في V1)* | `###-S5-PC` |
| AI *(مؤجل — لا يُستخدم في V1)* | `###-S5-AI` |
| Quality/Testing | `###-S5-QA` |
| UX/Accessibility | `###-S5-UX` |

مثال: `012-S5-FR` = المتطلب الوظيفي رقم 12.

---

## 2. أعمدة المصفوفة الإلزامية

```
Requirement ID → Source/Decision → Screen/Flow → Entities → Release → Acceptance Test → Risk →
Implementation Task (Codex Batch) → Verification Evidence
```

| العمود | الوصف |
|---|---|
| Requirement ID | المعرّف الثابت (`012-S5-FR`) |
| Source/Decision | أي وثيقة/قسم نص عليه، أو أي ADR اعتمده |
| Screen/Flow | Today / Study / Practice / Library / Projects (Lite) |
| Entities | الكيانات المتأثرة من `SEED_MODEL_DATA.md` |
| Release | Foundation / V1-A / V1-C ... (راجع `LONG_TERM_EXPANSION.md` §4) |
| Acceptance Test | معيار قبول محدد من `ACCEPTANCE_CRITERIA.md` أو مُشتق منه |
| Risk | من `LEDGER_CHANGE.md` أو مخاطر جديدة |
| Implementation Task | رقم/اسم دفعة Codex |
| Verification Evidence | رابط تقرير PR / نتائج الاختبار |

---

## 3. مثال أولي

| Requirement ID | Source/Decision | Screen/Flow | Entities | Release | Acceptance Test | Task | Evidence |
|---|---|---|---|---|---|---|---|
| 001-S5-FR | YEAR_ONE_SCOPE §2 | Practice | DrawingSession, Exercise, Attempt | Foundation | ACCEPTANCE_CRITERIA §2 | TBD | TBD |
| 001-S5-NFR | ACCEPTANCE_CRITERIA §1 | (كل الواجهات) | — | Foundation | Gate 0 pen latency test | TBD | TBD |
| 001-S5-DATA | YEAR_ONE_SCOPE §2 (Autosave) | (كل الواجهات) | Stroke, RecoverySnapshot | Foundation | ACCEPTANCE_CRITERIA §3 | TBD | TBD |

> يُملأ الجدول الكامل عند إنتاج Master Specification المعتمدة رسميًا (بعد Context Ingestion Report). هذا
> قالب جاهز للبدء.

---

## 4. قاعدة الاستخدام

- لا تُنشأ دفعة Codex بدون معرّف Requirement مرتبط بها.
- لا يُغلق Requirement بدون Evidence حقيقي (نتائج اختبار، لقطة، Diff).
- أي متطلب يُلغى أو يُؤجَّل يُنقل حالته هنا **ويُسجَّل السبب في** `LEDGER_CHANGE.md` — لا يُحذف من الجدول بصمت.
